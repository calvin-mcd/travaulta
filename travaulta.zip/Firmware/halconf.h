#pragma once

#define HAL_USE_ADC TRUE

#include_next <halconf.h>
