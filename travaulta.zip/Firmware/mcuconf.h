#pragma once

#include_next "mcuconf.h"

#undef STM32_ADC_USE_ADC1
#define STM32_ADC_USE_ADC1 TRUE
