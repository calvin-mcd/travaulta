#pragma once

#define VIAL_KEYBOARD_UID {0xCC, 0x83, 0xC5, 0x1A, 0x04, 0x7F, 0xB5, 0x34}

#define VIAL_UNLOCK_COMBO_ROWS { 0, 0 }
#define VIAL_UNLOCK_COMBO_COLS { 0, 10 }
